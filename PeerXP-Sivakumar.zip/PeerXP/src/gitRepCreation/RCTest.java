package gitRepCreation;

import java.io.FileInputStream;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class RCTest {
	public static WebDriver d;
  @Test
  public void f() throws BiffException, IOException {
	  FileInputStream f=new FileInputStream("C:\\Users\\dell\\Desktop\\SampleTD.xls");
	  Workbook b=Workbook.getWorkbook(f);
	  Sheet sl=b.getSheet("TC1");
	  Sheet sr=b.getSheet("TC2");
	  String[][] U=new String[0][];
	  String[][] P=new String[1][];
	  String[] R=new String[sr.getRows()];
	  Login l=PageFactory.initElements(d, Login.class);
	  for(int i=0;i<sl.getRows();i++) {
		  U[0][i]=sl.getCell(0,i).getContents();
		  l.UserName(U[0][i]);
		  P[1][i]=sl.getCell(1,i).getContents();
		  l.Password(P[1][i]);
		  l.Submit();
	  }
	  Repository r=PageFactory.initElements(d, Repository.class);
	  for(int x=0;x<sr.getRows();x++) {
		  R[x]=sr.getCell(0, x).getContents();
		  r.New();
		  r.DD();
		  r.RepositoryName(R[x]);
		  r.CreateRepository();
	  }
  }
}

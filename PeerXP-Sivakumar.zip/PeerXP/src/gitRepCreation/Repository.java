package gitRepCreation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class Repository {
	public static WebDriver d;	
	public Repository(WebDriver d) {
		Repository.d=d;
	}
	@FindBy(how=How.XPATH,using="//details[@class='details-overlay details-reset']/summary")WebElement Add;
	@FindBy(how=How.XPATH,using="//details[@class='details-overlay details-reset']//details-menu")WebElement AddDD;
	WebElement RN=d.findElement(By.xpath("//input[@id='repository_name']"));
	WebElement CR=d.findElement(By.xpath("//button[@class='btn btn-primary first-in-line']"));
	
	public void New() {
		Add.click();
	}
	public void DD() {
		Select s=new Select(AddDD);
		s.selectByValue("New repository");
	}
	public void RepositoryName(String rn) {
		RN.sendKeys(rn);
	}
	public void CreateRepository() {
		CR.click();
	}
}

package gitRepCreation;

import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class TestBase {
	WebDriver d;
  @BeforeTest
  public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver", "C:\\Program Files (x86)\\Selenium Jars\\chromedriver 88.exe");
	  d=new ChromeDriver();
	  d.manage().window().maximize();
	  d.get("https://github.com/login");
	  d.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
  }

  @AfterTest
  public void afterTest() throws InterruptedException {
	  Thread.sleep(5000);
	  d.close();
  }

}

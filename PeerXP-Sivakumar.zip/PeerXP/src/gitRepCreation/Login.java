package gitRepCreation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Login {
	public static WebDriver d;
	
	public Login(WebDriver d) {
		Login.d=d;
	}
	
	WebElement UN=d.findElement(By.xpath("//input[@name='login']"));
	WebElement PW=d.findElement(By.xpath("//input[@name='password']"));
	WebElement B=d.findElement(By.xpath("//input[@class='btn btn-primary btn-block']"));
	@FindBy(how=How.XPATH,using="//a[contains(text(),'Forgot password')]")WebElement FP;
	@FindBy(how=How.XPATH,using="//a[contains(text(),'Create an account')]")WebElement CNA;
	
	public void UserName(String u) {
		UN.sendKeys(u);
	}
	public void Password(String p) {
		PW.sendKeys(p);
	}
	public void Submit(){
		B.click();
	}
	public void ForgotPassword() {
		FP.click();
	}
	public void NewAccount() {
		CNA.click();
	}

}

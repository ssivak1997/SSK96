package pom;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Booking  extends TripMode{

	public Booking(WebDriver d) {
		super(d);
		}
	
	@FindBy(how=How.XPATH,using="//input[@id='BE_flight_origin_city']")WebElement From;
	@FindBy(how=How.XPATH,using="BE_flight_arrival_city")WebElement To;
	@FindBy(how=How.XPATH,using="//div[@class='ac_results origin_ac']/ul/div/div/div/li")List<WebElement> FList;
	@FindBy(how=How.XPATH,using="//div[@class='ac_results dest_ac']/ul/div/div/div/li")WebElement TList;
	
	public void Start(String from) {
		From.sendKeys(from);
	}
	public void Finish(String to) {
		To.sendKeys(to);
	}
	public void SDD() {
		int i=0;
		
	}

}

package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class TripMode extends TestBase{
	public static WebDriver d;
	
	public TripMode(WebDriver d) {
		TripMode.d=d;
	}
	
	@FindBy(how=How.XPATH,using="//*[@id='booking_engine_flights']")WebElement TM;
	@FindBy(how=How.XPATH,using="//*[@title='One Way']")WebElement TO;
	@FindBy(how=How.XPATH,using="//*[@class='ico ico-checkbox']//parent::a[@title='Non Stop Flights']")WebElement NSF;
	
	public void Mode() {
		TM.click();
	}
	public void Option() {
		TO.click();
	}
	public void Type() {
		NSF.click();
	}

}

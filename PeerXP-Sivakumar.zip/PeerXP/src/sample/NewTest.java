package sample;

import org.testng.annotations.Test;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.AcceptAlert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class NewTest {
	WebDriver d;
	WebDriverWait wait;
	String st[][]=null;
	String f[][]=null;
	
  @SuppressWarnings("null")
@Test
  public void f() throws BiffException, IOException {
	  FileInputStream td=new FileInputStream("C:\\Users\\dell\\Desktop\\SampleTD.xls");
	  Workbook td1=Workbook.getWorkbook(td);
	  Sheet s=td1.getSheet(0);
	  int r=s.getRows();
	  for(int i=0;i<r;i++) {
		  String temp[][]=null;
		  st[0][r]=temp[0][i];
		  f[1][r]=temp[1][i];
	  }
	  d.findElement(By.xpath("//*[@id='booking_engine_flights']")).click();
	  d.findElement(By.xpath("//a[contains(text(),'One Way')]")).click();
	  for(int i=0;i<r;i++) {
		  String s1=st[0][r];
		  String f1=f[1][r];
		  d.findElement(By.xpath("//input[@id='BE_flight_origin_city']")).sendKeys(s1);
		  List <WebElement> SC=d.findElements(By.xpath("//div[@class='ac_results origin_ac']/ul/div/div/div/li"));
		  for(int i1=0;i1<SC.size();i1++) {
			  WebElement t=SC.get(i1);
			  if(t.getText().startsWith(s1)) {
				  SC.get(i1).click();
			  }
		  }
		  d.findElement(By.xpath("//input[@id='BE_flight_arrival_city']")).sendKeys(f1);
		  List <WebElement> DC=d.findElements(By.xpath("//div[@class='viewport']/div[1]/div/li"));
		  for(int j1=0;j1<DC.size();j1++) {
		      WebElement t1=DC.get(j1);
			  if(t1.getText().startsWith(s1)) {
			  DC.get(j1).click();
			  }
  }
		  Select sdate=new Select(d.findElement(By.xpath("//input[@class='custom-date-input BE_flight_origin_date']")));
		  sdate.selectByValue("21-01-2021");
		  Select rdate=new Select(d.findElement(By.xpath("//input[@class='custom-date-input BE_flight_arrival_date']")));
		  rdate.selectByVisibleText("22-01-2021");
		  d.findElement(By.xpath("//div[@class='dflex filter-box']/div[2]//input[@id='BE_flight_flsearch_btn']")).click();
  }
  }
  
  @BeforeTest
  public void beforeTest(){
	  System.setProperty("webdriver.chrome.driver", "C:\\Program Files (x86)\\Selenium Jars\\chromedriver.exe");
	  d=new ChromeDriver();
	  d.manage().window().maximize();
	  d.get("https://www.yatra.com/");
	  d.switchTo().alert().accept();
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='booking_engine_flights']")));
	  
	  }
	  

  @AfterTest
  public void afterTest() {
	  d.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	  d.close();
  }

}

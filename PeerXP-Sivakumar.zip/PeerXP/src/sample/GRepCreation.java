package sample;

import org.testng.annotations.Test;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class GRepCreation {
	WebDriver d;
	@Test
	  public void login() throws BiffException, IOException {
		System.out.println("Entered TestBody");
		  FileInputStream f=new FileInputStream("C:\\Users\\dell\\Desktop\\SampleTD.xls");
		  Workbook b=Workbook.getWorkbook(f);
		  Sheet sl=b.getSheet("TC1");
		  Sheet sr=b.getSheet("TC2");
		  String[][] U=new String[sl.getColumns()][sl.getRows()];
		  String[][] P=new String[sl.getColumns()][sl.getRows()];
		  String[] R=new String[sr.getRows()];
		System.out.println("DataDriven completed");
		  WebElement B=d.findElement(By.xpath("//input[@class='btn btn-primary btn-block']"));
		  for(int i=0;i<sl.getRows();i++) {
			  U[0][i]=sl.getCell(0,i).getContents();
			  d.findElement(By.xpath("//input[@name='login']")).sendKeys((U[0][i]));
			  P[1][i]=sl.getCell(1,i).getContents();
			  d.findElement(By.xpath("//input[@name='password']")).sendKeys(P[1][i]);
			  B.click();
		  System.out.println("Login Completed");
		  WebElement Add=d.findElement(By.xpath("//details[@class='details-overlay details-reset']/summary"));
		  Add.click();
		  WebElement NR=d.findElement(By.xpath("//*[@class='dropdown-menu dropdown-menu-sw']/a[contains(text(),'New repository')]"));
		  NR.click();
		  WebElement RN=d.findElement(By.xpath("//input[@id='repository_name']"));
		  WebElement CR=d.findElement(By.xpath("//button[@class='btn btn-primary first-in-line']"));
		  for(int x=0;x<sr.getRows();x++) {
			  R[x]=sr.getCell(0, x).getContents();
			  RN.sendKeys(R);
			  CR.click();
		  }
		  }
		  System.out.println("Repository Created");
	  }  
	@BeforeTest
	public void beforeTest() {
		  System.setProperty("webdriver.chrome.driver", "C:\\Program Files (x86)\\Selenium Jars\\chromedriver 88.exe");
		  d=new ChromeDriver();
		  d.manage().window().maximize();
		  d.get("https://github.com/login");
		  d.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	  }
    @AfterTest
	public void afterTest() throws InterruptedException {
		  Thread.sleep(5000);
		  d.close();
	  }

}
